<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\File;
use App\Models\Models;
use App\Models\Brands;

class ModelsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $jsonFile = database_path('json/models.json');

        if (File::exists($jsonFile)) {
            $json = File::get($jsonFile);
            $models = json_decode($json, true);

            foreach ($models as $model) {

                $brand = Brands::where('name', $model['brand_name'])->first();

                if(!$brand)   
                    $brand_id = Brands::insertGetId([
                        'name' => $model['brand_name'],
                    ]);
                else  $brand_id = $brand->id;

                Models::updateOrInsert(
                    ['name' => $model['name']],
                    [
                        'average_price' => $model['average_price'],
                        'brand_id' => $brand_id,
                    ]
                );
            
        }}
    }
}